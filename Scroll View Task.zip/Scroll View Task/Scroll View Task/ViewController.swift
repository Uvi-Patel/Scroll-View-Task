//
//  ViewController.swift
//  Scroll View Task
//
//  Created by MAC on 08/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIScrollViewDelegate {
    
    @IBOutlet weak var viewOne: UIView!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var btnBrowse: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    var imgPicker = UIImagePickerController()
    var imageTaken = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.layer.borderColor = UIColor.black.cgColor
        scrollView.layer.borderWidth = 1.0
    }
    
    @IBAction func clickToOpen(_ sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            imgPicker.delegate = self
            imgPicker.sourceType = .savedPhotosAlbum
            imgPicker.allowsEditing = false
            present(imgPicker, animated: true, completion: nil)
            
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imageTaken.append((info[.originalImage] as? UIImage)!)
        imgPicker.dismiss(animated: true, completion: nil)
        self.ScrollViewDesign()
    }
    
    func ScrollViewDesign()
    {
        
        scrollView.subviews.map { $0.removeFromSuperview() }
        
        var xPosition = 10
        
        for i in 0..<imageTaken.count {
            let imageView = UIImageView()
            imageView.image = imageTaken[i]
            imageView.isUserInteractionEnabled = true
//            imageView.tag = 1000+i
            //            imageView.contentMode = .scaleAspectFill
            print(CGFloat(xPosition))
            imageView.frame = CGRect(x: CGFloat(xPosition), y: 10, width: self.scrollView.frame.size.height - 20 , height: self.scrollView.frame.size.height - 20)
            imageView.layer.borderColor = UIColor.green.cgColor
            imageView.clipsToBounds = true
            imageView.layer.borderWidth = 1.0
            
            let btnDlt = UIButton()
            btnDlt.frame = CGRect(x: 105, y: 5, width: 20, height: 20)
            btnDlt.setTitle("X", for:   .normal)
            btnDlt.backgroundColor = .red
            btnDlt.tag = 5000+i
            btnDlt.addTarget(self, action: #selector(clickToDlt(_:)), for: .touchUpInside)
            imageView.addSubview(btnDlt)

            scrollView.addSubview(imageView)
            xPosition = xPosition + (Int(imageView.frame.size.height)) + 10
        }
        scrollView.contentSize.width = CGFloat(xPosition)
    }
    @IBAction func clickToDlt(_ sender: UIButton?) {
        
        print(sender?.tag)
        var taggg = sender?.tag
        taggg = taggg! - 5000
        imageTaken.remove(at: taggg!)
        
//        imageTaken = tag - 5000
        
        
        self.ScrollViewDesign()
    }
    
//    @IBAction func clickToDlt(_ sender: UIButton){
//        print("dlt")
//
//                let subViews = self.scrollView.subviews
//                for subview in subViews {
//                    subview.removeFromSuperview()
////                    scrollView.reloadInputViews()
//                }
//        //        imageView.removeFromSuperview()
//    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
}



